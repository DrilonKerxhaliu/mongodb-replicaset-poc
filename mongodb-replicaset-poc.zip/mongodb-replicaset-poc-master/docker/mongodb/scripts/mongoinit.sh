#!/bin/bash

openssl rand -base64 700 > file.key
chmod 400 file.key
chown 999:999 file.key
